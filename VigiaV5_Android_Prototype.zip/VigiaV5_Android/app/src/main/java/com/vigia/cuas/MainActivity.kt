package com.vigia.cuas

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var captureButton: Button
    private var imageCapture: ImageCapture? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        val options = ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .build()
        ObjectDetection.getClient(options)
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCameraPermission()) startCamera()
            else status.text = "Permiso de cámara requerido para iniciar."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        if (hasCameraPermission()) startCamera()
        else permissionLauncher.launch(arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ))
    }

    private fun buildInterface() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 24, 32))
            setPadding(20, 20, 20, 20)
        }
        val heading = TextView(this).apply {
            text = "VIGÍA C-UAS  |  V5"
            textSize = 22f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Preparando cámara y detector visual…"
            textSize = 14f
            setTextColor(Color.rgb(150, 230, 190))
            setPadding(0, 12, 0, 12)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        captureButton = Button(this).apply {
            text = "REGISTRAR EVIDENCIA"
            isEnabled = false
            setOnClickListener { saveEvidence() }
        }
        val note = TextView(this).apply {
            text = "Aviso: el detector reconoce objetos genéricos. No confirma que un objeto sea un dron."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 0)
        }
        layout.addView(heading)
        layout.addView(status)
        layout.addView(previewView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        layout.addView(captureButton)
        layout.addView(note)
        setContentView(layout)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                val mediaImage = proxy.image
                if (mediaImage == null) {
                    proxy.close()
                    return@setAnalyzer
                }
                val input = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                detector.process(input)
                    .addOnSuccessListener { objects ->
                        runOnUiThread {
                            status.text = "Cámara activa · objetos visibles: ${objects.size}"
                            captureButton.isEnabled = true
                        }
                    }
                    .addOnFailureListener {
                        runOnUiThread { status.text = "Cámara activa · análisis no disponible" }
                    }
                    .addOnCompleteListener { proxy.close() }
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis
                )
            } catch (e: Exception) {
                status.text = "No se pudo iniciar la cámara: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun saveEvidence() {
        val capture = imageCapture ?: return
        val folder = File(filesDir, "evidencias").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val photo = File(folder, "VIGIA_$stamp.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(photo).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    val location = getLastKnownLocation()
                    val lat = location?.latitude?.toString() ?: "no_disponible"
                    val lon = location?.longitude?.toString() ?: "no_disponible"
                    val metadata = File(folder, "VIGIA_$stamp.txt")
                    metadata.writeText(
                        "VIGÍA C-UAS V5\n" +
                        "Fecha local: $stamp\n" +
                        "Latitud: $lat\nLongitud: $lon\n" +
                        "Imagen: ${photo.name}\n" +
                        "Nota: evidencia visual; no constituye confirmación de dron.\n"
                    )
                    Toast.makeText(this@MainActivity,
                        "Evidencia guardada en ${photo.name}", Toast.LENGTH_LONG).show()
                }
                override fun onError(exception: ImageCaptureException) {
                    Toast.makeText(this@MainActivity,
                        "Error al guardar: ${exception.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun getLastKnownLocation(): Location? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return null
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        return try {
            val gps = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            gps ?: manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (_: SecurityException) { null }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        detector.close()
    }
}
